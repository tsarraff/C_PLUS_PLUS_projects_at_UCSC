#include "linkedlist.h"
#include <iostream>
#include <fstream>
#include <cstring>
#include <stack>
#include <stdexcept>
#include <fstream>
#include <array>
#include <vector> 
#include <algorithm>
#include <sstream>
#include <string>

using namespace std;


LinkedList :: LinkedList(){
  head = NULL;
}

void LinkedList:: insert(string name, int x){
  Node *new_node = new Node;
  new_node->data = x;
  new_node->name = name;
  new_node->next = head;
  head = new_node;
  
}

Node* LinkedList:: find(string x){
  Node *s = head;
  while(s!=NULL){
    if(s->name == x){
      return s;
    }
    s = s->next;
  }
  return NULL;
}

Node* LinkedList:: delete_node(string x){
  Node *prev = NULL;
  Node *curr = head;
  while(curr!=NULL){
    if(curr->name ==x){
      break;
    }
    prev = curr;
    curr = curr->next;
  }
  if(curr == NULL){
    return NULL;
  }
  if(prev == NULL){
    prev = curr->next;
  }else{
    prev->next = curr->next;
  }
  return curr;
}

void LinkedList:: delete_list(){ //make sure
  Node *temp = NULL;
  while(head!=NULL){
    temp = head->next;
    delete(head);
    head = temp;
  }
}

int LinkedList:: length(){
  Node *curr = head;
  int counter = 0;
  while(curr!=NULL){
    counter+=1;
    curr = curr->next;
  }
  return counter;
}

string LinkedList:: print(){
  Node *node = head;
  string str = "";
  while(node!=NULL){
   //str = str + to_string(node->data) + " ";
    str = str + node->name + " ";
    node = node->next;
  }
  if(str.length()>0){
    str.pop_back();
  }
  return str;
}
bool LinkedList:: check(Node *s, Node*s1){
  if((s1->next->data<s->next->data) || ((s1->next->data == s->next->data) && (s1->next->name>s->next->name))){
    return true;
  }
  return false;
}
bool LinkedList::check1(Node*s){
  if((s->next->data < s->data) || ((s->next->data == s->data) && (s->next->name > s->name))){
    return true;
  }
  return false;
}

void LinkedList:: sort(){
	Node *s = new Node;
	s->next = head;
	Node *curr = head;
	Node *prev = s;
	while(curr!=NULL){
		if(curr->next!=NULL && check1(curr)){
			while(prev->next!=NULL && check(curr, prev)){
				prev = prev->next;
			}
			Node *temp = prev->next;
			prev->next = curr->next;
			curr->next = curr->next->next;
			prev->next->next = temp;
			prev = s;
 		
	}else{
			curr = curr->next;
		}
	
	}
} 

void LinkedList:: reverse(){
  Node *prev = NULL;
  Node *curr = head;
  Node *next;
  while(curr!=NULL){
    next = curr->next;
    curr->next = prev;
    prev = curr;
    curr = next;
    
  }
  head = prev;
}

string LinkedList:: printer(string val){
  Node *curr = head;
  int counter = 0;
  string var = "";
  while(curr!=NULL){
    if (counter == stoi(val)){
      var += curr->name + " " + to_string(curr->data);
      break;
    }
    counter+=1;
    curr = curr->next;
  }
  return var;
}
