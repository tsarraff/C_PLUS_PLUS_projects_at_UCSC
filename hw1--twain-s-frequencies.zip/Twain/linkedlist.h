#ifndef LIST_H
#define LIST_H


#include <string>
#include<iostream>

using namespace std;

struct Node{
  int data;
  string name;
  Node *next;
};
class LinkedList{
  private:
    Node *head;
  public:
    LinkedList();
    void insert(string,int);
    Node *find(string);
    Node *delete_node(string);
    void delete_list();
    int length();
    string print();
		void sort();
    void reverse();
    string printer(string);
    bool check(Node*, Node*);
    bool check1(Node*);
};

#endif