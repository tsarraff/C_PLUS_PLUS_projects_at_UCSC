#include "linkedlist.h"
#include <iostream>
#include <fstream>
#include <cstring>
#include <stack>
#include <stdexcept>
#include <fstream>
#include <array>
#include <vector> 
#include <algorithm>
#include <sstream>
#include <string>
using namespace std;
int main(int argc, char **argv){
  if(argc==3){
  
  ifstream input;
  ofstream output;
  string word;
  input.open("twain-cleaned.txt");
  LinkedList list [26];
  for(int i = 0; i<26;i++){
    list[i] = LinkedList();
  }
  
  while(getline(input,word)){
		if(int(word[0])-97 >=0 && int(word[0])-97<=25){
			
			Node *finder = list[int(word[0])-97].find(word);
			
			if(finder!=NULL){
				finder->data +=1;
			}else{
				list[int(word[0])-97].insert(word,1);
				}
    
    }
 
	}
input.close();
ifstream input1;

for(int i = 0; i<26;i++){
  list[i].sort();
  list[i].reverse();
}

input1.open(argv[1]);
output.open(argv[2]);

string word1;


while(getline(input1, word1)){
  
  int len = word1.length();
  string num = word1.substr(2,len);
  if(list[int(word1[0])-97].length() > stoi(num)){
    output << list[int(word1[0])-97].printer(num)<<endl;
  }else{
    output << "-"<<endl;
  }
  
  
}
}

}
  

