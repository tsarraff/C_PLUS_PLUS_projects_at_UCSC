cd RoboGrader
python3 robochecker.py Twain ~/workspace
cd ..
