#include <iostream>
#include <fstream>
#include <cstring>
#include <stack>
#include <stdexcept>
#include <fstream>
#include <array>
#include <vector> 
#include <algorithm>
#include <sstream>
#include <string>
#include <stack>
#include <tuple>
using namespace std;



bool check(int row_arr [],int column, int row, int size){
	for(int i = 0; i< size; i++){
		if(row_arr[i] == -1){
			row_arr[i] = 0;
		}
	}


  for(int i = 0; i < size; i++) {
    if(!(column == i+1 && row == row_arr[i])) {
      if(row_arr[i] != 0) {
        if((row_arr[i] - 1 ) == (row-1) ) {
          return false;
        }
				if((row_arr[i] + i - 1)  == ((row-1)+(column-1))){
					return false;
				}
				if((row_arr[i] - i - 1) == ((row-1)-(column-1))){
					return false;
				}
      } 
    }
  }
	return true;
}





int main(int argc, char** argv){

  
  ifstream input;
  ofstream output;
  string word;
  input.open(argv[1]);
  output.open(argv[2]);
  stack<int> row_stack;
  char *c, *val;
  int size;

  while(getline(input, word)){
    int x = 0;
		int y = 0;
		int numberofval = 0;
    c = strdup(word.c_str());
    val = strtok(c, " ");
    size = stoi(val);
    val = strtok(NULL, " ");
    int input_row [size];
    memset(input_row, 0, sizeof(input_row));
    int arr [size];

    while(val!=NULL){
      input_row[stoi(val) -1] = stoi(strtok(NULL, " "));
			if(input_row[stoi(val) -1]>size || input_row[stoi(val) -1]<0 || stoi(val) -1 >size|| stoi(val) -1<0 || size<1){
				output<< "No solution"<<endl;
				y = 1;
				break;
			}
			numberofval+=1;
      val = strtok(NULL, " ");
  }
		if(numberofval>size){
			output<< "No solution"<<endl;
			y = 1;
		}
		if(y !=1){
			int row = 1;
			int column = 1;
			for(int i = 0; i< size;i++){
				if(input_row[i] == 0){
					arr[i] = -1;
				}else{
					arr[i] = input_row[i];

					if(!check(input_row, i+1, input_row[i], size)){
						output << "No solution"<<endl;
						x = 1;
						column = size+1;
						break;
					}

				}

			}



			while(row<=size && column<=size){
				if(x == 1){
						break;
				 }
				if(input_row[column-1] != 0){
					row_stack.push(input_row[column-1]);
					column+=1;
					row = 1;
				}else if(check(arr, column, row, size)){
					row_stack.push(row);
					arr[column-1] = row;
					row = 1;
					column+=1;
				}else{
						row+=1;
					}
				if(row>size){
					if(input_row[column-1] == 0){
						arr[column-1] = -1;
					}
					column-=1;
					if(!row_stack.empty()){
						row = row_stack.top()+1;
						row_stack.pop();
					}

					while(row>size||input_row[column-1] != 0){
						if(input_row[column-1] == 0){
							arr[column-1] = -1;
						}
						column-=1;
						if(column<1){
							output<< "No solution"<<endl;
							x = 1;
							break;
						}
						row = row_stack.top()+1;
						row_stack.pop();
					}

				}

				if(row_stack.size() == size){
					break;
				}
			}


			int check = size-1;
			int numarr[size];
			int counter = 1;
			while(!row_stack.empty()){
				 numarr[check] = row_stack.top();
				 check-=1;
				 row_stack.pop();

			}
		 if(x!=1){
			for(int i = 0;i<size;i++){
				output<< counter << " "<<numarr[counter-1] << " ";
				counter+=1;
			}
			output<<endl;

		}
 }
}
}



    



